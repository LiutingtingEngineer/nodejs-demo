

export const AUTH_SINGAPORE = '28807e20-84e9-11ee-b098-1bee0315d36a';